Phase 1 is closed and verified. Start Phase 2 (Buyer auth + profile) per execution-spec §4 and §10.

SCOPE

1. OTP request/verify endpoints, enforcing every rule in §4:
   - Code hashed (sha256 + server secret via OTP_HASH_SECRET), never stored plaintext.
   - 10-minute expiry. One active code per email — a new request invalidates the prior one.
   - Max 5 verification attempts per code, then invalidated.
   - Rate limits: 3 OTP requests per email per 15 min, 10 per IP per 15 min.
   - Generic responses — never reveal whether an email is already registered.
   - Constant-time comparison for the OTP hash check (same discipline as the admin password
     comparison described in §9 — this wasn't explicitly called out for OTP but the rationale is
     identical: don't let response timing leak whether a guess was close).
2. Send the OTP code using the existing email utility from Phase 1 (server/src/email/send.ts) —
   don't build a second email path. This is the first real test of that utility under a
   correctness-critical use case (a buyer with a non-arriving OTP has no fallback login), so
   confirm actual delivery the same way Phase 1 did: through the real endpoint, checked against
   Resend logs/message IDs, not a function call in isolation.
3. Session middleware: buyer sessions 30-day rolling expiry (extends on activity), stored in
   Postgres per the existing sessions table. Also stand up the admin session type/middleware now
   (distinct session flag, 24-hour fixed expiry, no rolling extension) even though the full admin
   UI doesn't arrive until Phase 4 — the original spec's Phase 2 exit tests require verifying
   admin session expiry, so the scaffolding needs to exist here.
4. Register-completion flow: first successful OTP for a new email creates the BuyerProfile shell,
   routes to profile completion.
5. Login flow for existing emails.
6. My Profile page: all profile fields, alert preferences, consent timestamps, opt-in toggles.
7. Full-passport unlock for authenticated buyers.
8. Logout endpoint, destroys the session.
9. Honeypot field on the OTP-request/registration form, per §9.
10. zod validation on every new endpoint, strict/reject-unknown-fields — same standard as
    Phase 1, not a relaxed version because this feels like "just auth."
11. Lazy cleanup: expired otpCodes and sessions purged opportunistically on OTP request and
    session validation — no cron jobs.

CARRIED FORWARD FROM PHASE 1 — RE-VERIFY, DON'T ASSUME

The gated-field JSON check ("anonymous response has no gated fields, authenticated response has
them") was only ever tested by calling serializeLot() directly, since no real session existed
yet. Now that sessions exist, re-run this through actual HTTP requests: an anonymous GET and an
authenticated GET (real session cookie, not a stubbed call) against the same lot, both asserted
on raw JSON. Route/middleware wiring is a different failure surface than the serialization
function — confirm both, don't treat the Phase 1 result as still sufficient.

EXIT TESTS — REPORT PER ITEM WITH EVIDENCE, NOT A SUMMARY

Use the same reporting discipline as the Phase 1 corrected report: exact numbers for anything
rate-limit-related, confirmation method stated for anything delivery-related, and root cause
named for anything that was ever wrong. A checkmark with no evidence isn't a pass.

- New-email flow creates a BuyerProfile and session.
- Existing-email flow logs in successfully.
- Expired code rejected; reused (already-consumed) code rejected; 6th verification attempt on
  the same code rejected.
- OTP rate limits enforced — scripted repeat calls, exact request-number-where-blocked reported
  (same rigor as the Phase 1 rate-limit re-verification: state the limit, show the boundary).
- Gated-field check re-verified through real authenticated + anonymous HTTP requests (see above).
- Profile edits persist correctly.
- consentTimestamp set when an opt-in toggle changes.
- Session cookie flags correct (httpOnly, secure, sameSite=lax).
- Buyer session extends on activity and expires after 30 days idle.
- Admin session expires at 24 hours with no rolling extension.
- OTP email delivery confirmed end-to-end through the real endpoint (Resend logs/message ID).

Commit and push after the phase is fully verified, then report back per-item before Phase 3 starts.
