# Before you paste this into Claude Code

This prompt assumes four files already exist at `docs/` in the repo Claude Code
will be working in:

1. `docs/FINCAVA_PLATFORM_HANDOVER.md`
2. `docs/FINCAVA_PLATFORM_CLAUDE_CODE_PROMPT.md`
3. `docs/FINCAVA_PLATFORM_ADDENDUM_VERIFICATION.md`
4. `docs/FINCAVA_Wireframes_dc_v2.html`

Steps before you start Claude Code:
1. Clone the empty repo: `git clone https://github.com/sbirfan/fincava-platform.git && cd fincava-platform`
2. `mkdir docs`
3. Copy the four files above into `docs/`.
4. `git add docs && git commit -m "Add planning docs" && git push`
5. Open Claude Code in this directory (terminal, VS Code extension, or desktop app — your choice), then paste the prompt below as your first message.

---

## The prompt

```
You are the senior full-stack engineer building the FINCAVA Platform from scratch in this
repository: https://github.com/sbirfan/fincava-platform

Before writing any code, read all four files in docs/:

1. docs/FINCAVA_PLATFORM_HANDOVER.md — the decision log. This is the "why" behind every
   architectural choice, and it explicitly lists what to avoid (old-platform patterns,
   overengineering signals). Read the "What to Watch For" section especially closely.
2. docs/FINCAVA_PLATFORM_CLAUDE_CODE_PROMPT.md — the execution spec. This is the primary
   source of truth for stack, data model, pages, and the phased build plan with exit tests.
3. docs/FINCAVA_PLATFORM_ADDENDUM_VERIFICATION.md — an amendment adding farm/lot verification
   requests as a first-class entity (new table, new admin stat, a public form that deliberately
   does NOT require buyer login). Treat this as modifying the execution spec, not as optional
   extra scope.
4. docs/FINCAVA_Wireframes_dc_v2.html — the approved wireframe for the "1a" marketplace-grid
   design direction. This is the visual and copy source of truth for Home, Available Lots,
   Lot Passport, About, Request Farm Verification, and the Admin Dashboard/Lots screens. Match
   its layout, component patterns, and exact copy. It references design tokens via CSS custom
   properties (--fc-sage, --fc-ink, --fc-paper, --fc-font-display, --fc-radius-lg, --fc-shadow-1,
   etc.) through a stylesheet path (fincava-ds/colors_and_type.css) that isn't included — you'll
   need to define real values for these tokens yourself (a warm sage-and-paper nature palette,
   a display serif/display font for headings, a plain sans for body text) and keep them
   consistent site-wide. Where the wireframe doesn't cover a page (Contact, Privacy, ToS,
   Login/Register/OTP, My Profile, RFQ/Sample/Sourcing forms, the full Admin Requests queue,
   Lot CRUD forms), follow the execution spec's page descriptions in §7 and match the wireframe's
   established visual language rather than inventing a different style.

CRITICAL RULES — do not deviate from these:
- No prior-platform architecture reuse. If you find yourself building compliance modules,
  supplier onboarding, graduation state machines, or buyer-matching algorithms, stop.
- No microservices, event buses, message queues, or autonomous agents.
- Stack is fixed per execution-spec §3: Vite + React + TypeScript + Tailwind frontend,
  Node + Express + TypeScript backend (single server serves API + built frontend in production),
  Neon Postgres via Drizzle ORM + drizzle-kit migrations, Resend for transactional email only,
  Cloudinary for images (nothing written to local filesystem or committed to git), server-side
  sessions in Postgres with httpOnly/secure/sameSite=lax cookies — no JWT in localStorage.
- Field gating (public / gated-buyer / admin-only) is enforced server-side. Verify with the raw
  JSON exit tests specified in the spec — a field hidden in the UI but present in the API
  response is a failed test, not a pass.
- Verification requests do NOT require buyer authentication — this is a deliberate, documented
  exception described in the addendum. Every other write endpoint (RFQ, sample, sourcing) DOES
  require an authenticated buyer session. Do not "fix" this inconsistency without asking me first
  — it's intentional, not an oversight.
- Never commit secrets. All configuration via environment variables; commit a `.env.example`
  with variable names only, never real values.
- Follow the phased plan in execution-spec §10 (as extended by the addendum's phase notes).
  Do not start a phase until the previous phase's exit tests pass. Report exit-test results at
  the end of each phase, in writing, before proceeding to the next.
- If anything in the four docs conflicts with what you find as you build, stop and ask me — don't
  silently resolve conflicts between the Handover, the execution spec, the addendum, or the
  wireframe.

START HERE — Phase 0 (Foundation):
1. Initialize repo structure per §3: /client, /server, /shared, /drizzle.
2. Tooling: TypeScript strict mode, ESLint, Prettier.
3. Express skeleton: helmet, structured logging, a centralized error handler that never leaks
   stack traces to clients.
4. Full Drizzle schema — every table and enum in execution-spec §5, PLUS the
   verificationRequests table and verification_status enum from the addendum.
5. Write the initial migration (don't run it against a real database yet — see note below).
6. Commit `.env.example` listing every variable from the execution spec's env-var table. The
   addendum's verification feature needs no additional secrets.
7. Seed script: 6 realistic Colombian lots covering all five pricing strategies, at least one
   visible=false INVITE_ONLY lot. Do NOT seed fake RFQs, sample requests, sourcing requests, or
   verification requests — leave those tables empty; they should only ever contain real
   submissions.
8. README stub. Replit-compatible run scripts: `npm run dev`, `npm run build`, `npm start`.
9. Don't attempt to run the migration against Neon yet — I'm setting up the Neon project and
   will hand you the connection string once it exists. Get everything ready to run the moment
   DATABASE_URL is available; tell me explicitly when you're at that point and waiting on it.

Report Phase 0 exit tests (fresh clone installs and boots; migration applies cleanly to an empty
DB once I give you credentials; seed loads; health endpoint responds; no secrets in git) before
moving to Phase 1. Commit and push after each phase with a clear message.
```
