Phase 3 is closed. Start Phase 4 (Admin) per execution-spec §4, §7, and §10, plus the addendum's
Phase 4 additions.

RETIRE THE BEARER-TOKEN STOPGAP — DO THIS FIRST, CLEANLY, NOT ALONGSIDE THE NEW AUTH

Phase 2 already scaffolded real admin session support (createAdminSession(), 24-hour fixed expiry,
no rolling extension, proven correct in isolation) but never wired it to a live route — the
Bearer-token check in server/src/middleware/adminAuth.ts and client/src/pages/AdminLot.tsx has been
the actual gate this whole time. Now that real admin auth is being built:

1. Build the real /admin/login page: single password field, checked against ADMIN_PASSWORD via
   constant-time comparison, creates an admin session on success. Rate limit: 5 attempts/IP/15min.
2. Wire the already-scaffolded admin session middleware to all /admin/* pages and /api/admin/*
   routes.
3. Remove the Bearer-token check entirely — from adminAuth.ts, from AdminLot.tsx, and grep the
   whole repo for any other reference to it. The two mechanisms should not coexist even briefly;
   don't leave the Bearer path as a fallback "just in case."
4. Confirm nothing else depended on the Bearer token (any hardcoded value, any other file reading
   it) before deleting it — re-run the same grep -ri bearer check from the Phase 2 follow-up to
   confirm zero hits remain anywhere in the codebase afterward.
5. Buyer sessions must not be able to reach any /admin/* route — verify with a real authenticated
   buyer session cookie against an admin API route, confirm 404 (not 401 — don't advertise the
   surface, per §9).

SCOPE — ADMIN MODULES (§7)

1. Dashboard: counts for new RFQs, new sample requests, new sourcing requests, new verification
   requests (per the addendum), and new registrations, all over the last 7 days. Lots-by-status
   breakdown.
2. Lots — full CRUD. Deletion guard: a lot referenced by any RFQ, sample request, sourcing
   matchedLotId, or verification linkedLotId cannot be deleted (surface "This lot has N linked
   requests — set status to SOLD instead"); unreferenced lots can be truly deleted. Cloudinary
   image upload (multi-image, preview, delete) — server-validated type (jpeg/png/webp) and size
   (≤5MB), admin-only. Visible toggle, status, pricing strategy, all passport fields.
3. Buyers — list + detail: profile, preferences, opt-in status, request history across all four
   types (RFQ/sample/sourcing/verification where linked), internalNotes editing. "Delete buyer"
   action: confirmation step required, then hard-deletes the profile and cascade-deletes all their
   RFQs, sample requests, sourcing requests, and sessions. (Verification requests aren't tied to a
   buyerProfileId per the addendum's deliberate no-auth design, so they're unaffected by buyer
   deletion — don't build a cascade path for them here.)
4. Requests — unified queue with FOUR tabs: RFQ, sample, sourcing, and verification (the fourth
   per the addendum). RFQ/sample use request_status; sourcing uses sourcing_status; verification
   uses verification_status. Each supports internalNotes. Sourcing supports linking matchedLotId;
   verification supports linking linkedLotId (same pattern, different field name per the schema).
5. Market Intelligence — CRUD for research notes, filter by variety/lot.
6. Alert Outreach — filter buyers by alertOptIn + preference criteria, view matching list,
   CSV export for manual outreach. No automated sending.

EXIT TESTS — SAME EVIDENCE STANDARD AS EVERY PRIOR PHASE

- Buyer session cannot reach any /api/admin route — 404, verified with a real buyer session cookie.
- Wrong admin password rate-limited at exactly 5/15min — show the request number where it blocks,
  not just "eventually blocked."
- A lot created via admin (with an uploaded image) appears correctly on the public site.
- INVITE_ONLY visible-toggle behavior matches spec (defaults false on creation, admin can flip to
  true, shows "Contact FINCAVA" with no price when visible).
- RFQ/sample status transitions persist (request_status); sourcing status transitions persist
  (sourcing_status); verification status transitions persist (verification_status).
- Admin can link matchedLotId to a sourcing request and linkedLotId to a verification request —
  test both, they're separate fields on separate tables.
- CSV export matches the applied filter — verify with a specific filter and check the exported
  rows against it, not just that a file downloads.
- Image upload >5MB rejected; wrong file type rejected.
- Deleting a buyer removes their profile and all their RFQs/samples/sourcing requests and
  sessions — assert on raw DB rows, and confirm their session cookie stops working immediately
  after deletion (test this with a live session, not just a DB check).
- A lot referenced by any request cannot be deleted; an unreferenced lot can be.
- No "[X]" or unresolved placeholder text remains in any buyer-facing copy or email template.
  IMPORTANT: this includes the "5 business days" verification response-time commitment, which the
  addendum flagged as a placeholder pending my confirmation — do not silently treat it as final.
  Flag it back to me explicitly in your report as still awaiting sign-off, separate from any
  genuine "[X]"-style placeholders you find and fix directly.
- The Bearer-token retirement items above (grep confirms zero remaining references, buyer-session
  404 test) are part of this phase's exit tests, not optional cleanup.

Commit and push after the phase is fully verified. Report back per-item, with the same evidence
standard as every prior phase, before Phase 5 starts.
