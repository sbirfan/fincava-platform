Before Phase 4 starts, resolve two items from the Phase 3 report — one is a security decision that
needs to be made deliberately, the other is a recurring deploy risk that needs a permanent fix, not
a note. A third item is informational only, no code change needed.

1. RATE-LIMIT BUCKET SHARING ACROSS /verification AND THE THREE BUYER FORMS — DECIDE, DON'T LEAVE
   AS A SIDE EFFECT OF REUSING ONE LIMITER INSTANCE

The report shows RFQ, sample, sourcing, and verification all draw from the same 10/hour/IP bucket.
Verification is the only endpoint on the site with no auth wall in front of it — that's exactly why
it got extra scrutiny in Phase 1. Sharing a bucket means an anonymous actor hammering
/verification from one IP can exhaust the same quota a legitimate authenticated buyer behind that
IP needs for RFQ/sample/sourcing (shared office network, corporate NAT, etc.).

Split /verification into its own separate 10/hour/IP bucket, independent from the three
buyer-authenticated forms. Confirm with a scripted test that exhausting one bucket doesn't affect
the other: max out /verification from an IP, then confirm an RFQ/sample/sourcing submission from
that same IP still succeeds, and vice versa. Report the before/after — show that today the buckets
are shared (reproduce the current behavior once, for the record) and then confirm they're
independent after the fix.

2. FIX THE BUILD-ORDER BUG PERMANENTLY — THIS WILL RECUR ON EVERY FUTURE PUSH UNTIL IT'S FIXED

The incident where Replit's redeploy didn't rebuild @fincava/shared before restarting, taking every
route down with 500s, is a build/deploy configuration gap — not a one-off. Fix the build command
itself so workspace dependencies are always rebuilt before the server starts, in the correct order,
on every deploy. Don't just document it as something to remember.

Also report, for the record:
- How long was the live deployment actually down (best estimate from logs/timestamps)?
- How was it noticed — manually, or is there any monitoring in place? If none, that's worth naming
  explicitly as a gap.
- Confirm the fixed build command with a real test: trigger a fresh deploy from a clean state and
  confirm the app comes up correctly on the first restart, not just after a manual rebuild.

Separately, since fincava.com will have real buyers soon: turn on Replit's own App Monitoring for
this deployment if it isn't already on, so a future outage gets caught by something other than
someone happening to notice. Report whether it's now enabled.

3. INFORMATIONAL — NO CODE CHANGE

The /api/me PATCH endpoint refusing to clear name/company to empty is correct behavior, not a bug
— those are very likely required fields on buyerProfiles, and allowing a buyer to null them out via
PATCH would be a worse problem than leftover QA data. Do not build an "allow clearing required
fields" path. I'm cleaning up my own test profile row directly in the database myself — no action
needed from you on this one.

Report back on items 1 and 2 with the evidence described above. Once both are resolved, give me
the updated Phase 3 status before I write the Phase 4 kickoff.
