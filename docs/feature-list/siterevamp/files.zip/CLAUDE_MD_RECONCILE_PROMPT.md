I've added CLAUDE.md to the repo root — durable project memory that reloads every session, meant
to survive /compact and /clear. Before I compact this session, verify it against the actual repo
rather than trusting it blindly:

1. Read CLAUDE.md.
2. Check the "Current status" section against reality: run git log, check the actual state of
   Phase 5's task list (contact/terms fixes, business-use/international clauses, fail-fast
   shared-package guard, README deploying section, final walkthrough) against what's actually
   committed. Update that section to reflect the real current state, including anything still
   genuinely in progress or not yet started.
3. Check every claim in "Deliberate decisions" against actual code — confirm each one is true
   right now (e.g., grep for "bearer" again to confirm zero hits, confirm the verification
   rate-limit bucket is actually separate, confirm Terms.tsx has the governing-law/business-use/
   international clauses, confirm Contact.tsx has the real phone/email). If anything in that
   section doesn't match what you find in the actual repo, fix the file to match reality and tell
   me what was wrong.
4. Do NOT treat this file as more authoritative than the actual codebase or the four docs in
   docs/ — if there's a genuine conflict, the code and the docs win, and CLAUDE.md needs correcting
   to match them.

Commit CLAUDE.md (with any corrections from step 3) and push. Then give me a short summary: what,
if anything, was wrong in my draft, and what Phase 5 items are genuinely still open right now.

After that, I'll run /compact.
