Before you continue with Phase 1, two scope decisions need to be locked in — both because
/verification changes what "Phase 1" means versus the original spec.

1. RATE LIMITING + HONEYPOT ON /verification ARE IN SCOPE FOR PHASE 1, NOT DEFERRED

The original execution spec wrote Phase 1 as a pure read/browse phase with no forms, so its
exit tests never mention rate limiting or honeypots — that was written before the verification
addendum existed. The addendum does require it ("rate limit and honeypot both verified with
scripted repeat calls, same as other public forms"), but make sure it's actually a checked exit
test for this phase, not something you're planning to pick up later alongside RFQ/sample/
sourcing in Phase 3.

/verification is the only endpoint on the entire site with no auth wall in front of it. Add to
your Phase 1 exit tests, and verify with actual scripted repeat calls before calling Phase 1 done:
- Rate limit: 10 submissions/hour/IP, matching the spec's general form rate limit.
- Honeypot field present and enforced (silently reject/ignore submissions where it's filled).
- zod validation on the POST body that rejects unknown fields — same discipline as every other
  endpoint per spec §9, not a relaxed "it's just a contact form" version.

2. BUILD THE RESEND EMAIL UTILITY NOW, IN PHASE 1, FOR THE TWO VERIFICATION EMAILS

The addendum specifies a requester-confirmation email and a founder-notification email for
verification requests, but doesn't say which phase builds them. Decision: build them now.

Build a small, reusable Resend-sending utility in Phase 1 — just enough to send these two email
types for verification requests. Reuse the exact non-blocking pattern already specified
elsewhere in the spec: fire after DB commit, log on failure, never fail the user's request.

- Requester confirmation: "We received your verification request. We'll respond within 5
  business days to discuss scope, timing, and pricing." (the addendum flags this number as a
  placeholder for Irfan to confirm — leave it as-is for now, don't invent a different number,
  and don't leave a literal "[X]" in the template.)
- Founder notification: fires on every new verification request, includes requester details and
  a link to the admin record.

When Phase 2 (OTP) and Phase 3 (RFQ/sample/sourcing confirmations) come around, they should
reuse this same email-sending utility rather than each wiring up Resend independently — treat
what you build now as the shared foundation, not a one-off for verification alone.

Once both of these are built and verified, give me an updated Phase 1 exit test report before
moving to Phase 2.
