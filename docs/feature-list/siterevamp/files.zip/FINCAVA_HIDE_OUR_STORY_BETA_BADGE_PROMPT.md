Three things, plus one status check.

## 1. Hide the Our Story page, with an easy way to re-enable it later

Keep the page and its content exactly as built — don't delete or rewrite anything. Just make it
not publicly visible for now, with a simple toggle to bring it back:

- Add a single boolean constant (e.g. `SHOW_OUR_STORY_PAGE = false` in a small config/flags file,
  not an environment variable — no new infra needed for a toggle this simple) that controls both:
  - whether the nav link to it appears;
  - whether the route itself is publicly reachable. When the flag is off, visiting `/our-story`
    directly should not render the page — redirect to Home or show the standard 404, your choice,
    but it shouldn't be reachable just because someone guesses or bookmarks the URL. A page that's
    merely unlinked but still fully live at its URL isn't actually hidden.
- Comment the flag clearly so it's obvious how to flip it back on later (e.g. "Set to true to
  publish the Our Story page").

## 2. Add a "Beta" indicator

FINCAVA is early-stage and doesn't have live lots yet (per the empty-catalog work). Add a small,
low-key "Beta" badge near the FINCAVA name/logo in the site header/nav, appearing site-wide across
all public pages. Keep it visually subtle — a small pill or label, not a banner that competes with
the primary nav. Match existing design-system patterns (colors, radius, type) rather than
introducing a new visual style.

Use your judgment on exact placement and styling within that guidance, but check it looks right at
mobile, tablet, and desktop before finishing — a badge that's fine on desktop can easily crowd a
mobile header.

## 3. Close out the two gaps from the last report

- Confirm exactly where the Our Story nav link was placed (top-level, nested under About, footer,
  etc.) — this wasn't stated last time and matters for when the page gets re-enabled later.
- Run `git diff client/src/pages/About.tsx` (or `git status` scoped to that file) and paste the
  actual output, confirming zero diff, per the original constraint. Don't infer it from "no console
  errors" — show the real diff result.

## 4. Status check

Report whether the separate empty-catalog-state prompt (hiding the 6 seed lots, building the
"No lots listed yet" empty state) has been started, and if so, its current state — that task was
sent before this one and I haven't seen a report on it yet.

## Validation

Run format/lint/build. Confirm `/our-story` is unreachable (redirects or 404s) with the flag off,
and confirm it renders correctly if you temporarily flip the flag on for testing (then set it back
to false before finishing). Confirm the Beta badge appears correctly across breakpoints and doesn't
break any existing layout.

Do not commit, push, or deploy — same standing rule as everything else. Report back with the flag
file's location and exact syntax, the nav-placement answer, the About.tsx diff output, the
empty-catalog-task status check, and validation results.
