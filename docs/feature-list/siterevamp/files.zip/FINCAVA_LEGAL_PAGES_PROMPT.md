Before starting: this replaces the Terms of Service content (including the governing-law/
business-use language added earlier this phase) and the Privacy Policy content, in full. Read
CLAUDE.md first for project facts and standing rules — two of them apply directly here:

1. VERIFIED FACTS TO USE DIRECTLY, NOT AS PLACEHOLDERS
   - Contact email for both pages: info@fincava.com (finalized this phase, not a placeholder —
     use it wherever the content below says to use a verified email or `[Contact Email]` /
     `[Privacy Contact Email]`).
   - Consent timestamps ARE implemented and verified: buyerProfiles.consentTimestamp is set on
     genuine opt-in/opt-out changes (tested and confirmed in Phase 2). Per the Privacy Policy
     content's own instruction ("only state that consent timestamps are recorded if verified"),
     include that sentence in Section 3 — it's verified true.
   - Effective Date: use today's date (the date this change is committed/deployed), not a
     placeholder — this is knowable, not something to leave blank.

2. RECONCILE WITH A PRIOR DELIBERATE DECISION
   The Terms content below (Section 9, Governing Law and Venue) is a more thorough version of
   governing-law language than what's currently in Terms.tsx, and should replace it. But it's
   missing one clause that was deliberately added earlier this phase and shouldn't be silently
   dropped: the international-buyer acknowledgment. Add this sentence at the end of Section 9,
   after the jury-trial waiver paragraph:

   "If you are located outside the United States, you expressly agree that Texas law and the
   forum described above govern these Terms and any dispute, except to the extent a mandatory
   law of your jurisdiction that cannot be waived by agreement provides otherwise."

   If you find any other content below conflicts with something already established as finalized
   in CLAUDE.md's "Deliberate decisions" section, flag it in your final report rather than
   silently choosing one version — don't assume the new content automatically wins.

Everything below this line is the actual task specification — follow it exactly as written,
including all of its own constraints on placeholders, verification, and what not to claim.

---

## Objective

Replace the existing legal-page content with the updated B2B-focused Terms of Service and Privacy
Policy provided in this prompt.

Do not redesign the website. Preserve the project's existing framework, routing conventions,
typography, spacing, navigation, footer, responsive behavior, and component patterns.

Before editing:

1. Inspect the repository structure and identify:
   - the Terms and Conditions or Terms of Service page;
   - the Privacy Policy page;
   - shared legal-page components or layouts;
   - the site-wide business name, contact email, business address, and route naming conventions.

2. Reuse verified business information already present in the repository (see the verified-facts
   note above — this satisfies part of this requirement already). Do not invent an address, email
   address, effective date, or company detail beyond what's given.

3. If a required value cannot be verified, use a clearly visible placeholder such as:
   - `[Effective Date]`
   - `[Privacy Contact Email]`

4. Do not change application logic, authentication, database behavior, cookie behavior,
   analytics, request handling, or data-retention systems. This task updates legal-page content
   only.

5. Do not add claims about FINCAVA's practices unless they are included below or verified in the
   codebase.

---

# Page 1: Terms of Service

Use the page title **Terms of Service**. If the existing public URL or navigation label is "Terms
and Conditions," preserve the existing route to avoid broken links, but use "Terms of Service" as
the primary page heading unless doing so conflicts with established project conventions.

Include the following content:

## Terms of Service

These Terms of Service ("Terms") govern access to and use of the FINCAVA platform (the
"Platform"), which is owned and operated by KR Industries LLC d/b/a FINCAVA ("FINCAVA," "we,"
"our," or "us").

By accessing or using the Platform, creating an account, browsing listings, or submitting any
request through the Platform, you agree to be bound by these Terms. If you access or use the
Platform on behalf of a business or other legal entity, you represent and warrant that you have
authority to bind that entity to these Terms.

### 1. Business-to-Business Platform

The Platform is intended solely for businesses, professional buyers, and commercial purchasers.
It is not intended for personal, household, or consumer transactions.

### 2. Listings Are Not Offers

Product listings, inventory information, specifications, photographs, descriptions, availability,
pricing, and other information published on the Platform are provided for informational purposes
only.

All listings constitute invitations to negotiate and do not constitute binding offers to sell.
Inventory availability, specifications, pricing, and other information may change at any time
without notice until confirmed by FINCAVA in a written quotation or executed sales agreement.

### 3. Requests Do Not Create a Contract

Submitting a request for quotation ("RFQ"), sourcing request, sample request, verification
request, or any other inquiry through the Platform does not create a contract or obligate FINCAVA
or the requesting party to proceed with a transaction.

No purchase or sale becomes binding unless and until the parties execute a separate written
agreement or FINCAVA issues a written acceptance of a purchase order or quotation, as applicable.

### 4. Pricing

Any pricing displayed on the Platform, including fixed prices, estimated prices, starting prices,
or price ranges, is provided for convenience only.

Displayed pricing is non-binding and subject to change without notice.

Unless expressly stated otherwise in a written quotation, prices exclude applicable taxes,
shipping, freight, insurance, customs duties, tariffs, and other governmental charges.

### 5. Platform Disclaimer

The Platform and all information made available through it are provided on an "AS IS" and "AS
AVAILABLE" basis.

To the fullest extent permitted by applicable law, FINCAVA disclaims all warranties, whether
express, implied, statutory, or otherwise, including implied warranties of merchantability,
fitness for a particular purpose, title, non-infringement, accuracy, completeness, and
uninterrupted availability.

FINCAVA does not warrant that Platform information is complete, current, accurate, error-free, or
suitable for any particular purpose.

### 6. Limitation of Liability

To the fullest extent permitted by applicable law, FINCAVA shall not be liable for any indirect,
incidental, consequential, special, exemplary, or punitive damages, including lost profits, lost
revenue, lost business opportunities, loss of data, or business interruption, arising from or
relating to the Platform or these Terms, regardless of the legal theory asserted.

FINCAVA's aggregate liability arising from or relating to these Terms or the Platform shall not
exceed the greater of:

1. US$100; or
2. the amount actually paid by the claimant to FINCAVA for use of the Platform during the twelve
   months preceding the event giving rise to the claim.

Nothing in these Terms excludes or limits liability that cannot lawfully be excluded or limited.

### 7. Intellectual Property

All content made available through the Platform, including its software, trademarks, service
marks, logos, text, graphics, photographs, databases, page layouts, and other materials, is owned
by or licensed to FINCAVA and is protected by applicable intellectual-property laws.

Access to or use of the Platform does not transfer any ownership rights to the user.

### 8. Acceptable Use

You agree not to:

- use the Platform for an unlawful, fraudulent, or unauthorized purpose;
- interfere with or disrupt the operation or security of the Platform;
- attempt to gain unauthorized access to an account, system, server, or network;
- copy, scrape, crawl, harvest, or systematically extract Platform content or data without
  FINCAVA's prior written consent;
- upload or transmit malware, malicious code, or other harmful material;
- impersonate another person or misrepresent your identity, authority, or affiliation; or
- use Platform information to compete with FINCAVA or circumvent FINCAVA in connection with a
  sourcing opportunity introduced through the Platform.

FINCAVA may restrict, suspend, or terminate access to the Platform for an actual or suspected
violation of these Terms.

### 9. Governing Law and Venue

These Terms and any dispute arising out of or relating to the Platform or these Terms shall be
governed by and construed in accordance with the laws of the State of Texas, without regard to
its conflict-of-laws principles.

Each party irrevocably submits to the exclusive jurisdiction of the state courts located in
Williamson County, Texas, and the applicable federal courts having jurisdiction over Williamson
County, Texas. Each party waives any objection based on improper venue or forum non conveniens.

**TO THE FULLEST EXTENT PERMITTED BY LAW, EACH PARTY KNOWINGLY AND VOLUNTARILY WAIVES ANY RIGHT TO
A TRIAL BY JURY IN AN ACTION OR PROCEEDING ARISING OUT OF OR RELATING TO THESE TERMS OR THE
PLATFORM.**

[Insert the international-buyer acknowledgment sentence from the reconciliation note above, here.]

### 10. Changes to These Terms

FINCAVA may modify these Terms from time to time. Updated Terms will become effective when posted
to the Platform unless a later effective date is stated.

Where required by applicable law, FINCAVA will provide additional notice of material changes.
Continued use of the Platform after revised Terms become effective constitutes acceptance of
those revised Terms.

### 11. Severability

If any provision of these Terms is determined to be invalid, unlawful, or unenforceable, that
provision shall be enforced to the maximum extent permitted by law, and the remaining provisions
shall remain in full force and effect.

### 12. No Waiver

A failure or delay by FINCAVA in exercising a right or remedy under these Terms does not waive
that right or remedy.

### 13. Entire Agreement and Transaction Documents

These Terms constitute the entire agreement between FINCAVA and the user regarding access to and
use of the Platform.

These Terms do not replace or modify a separately executed purchase agreement, sales contract,
written quotation, accepted purchase order, or other commercial agreement governing a specific
transaction. If there is a conflict concerning a specific transaction, the separately executed or
accepted transaction document shall control to the extent of that conflict.

### 14. Contact

Questions concerning these Terms may be sent to:

**FINCAVA**
KR Industries LLC
info@fincava.com

---

# Page 2: Privacy Policy

Use the page title **Privacy Policy**.

Include the following content:

## Privacy Policy

KR Industries LLC d/b/a FINCAVA ("FINCAVA," "we," "our," or "us") respects your privacy and is
committed to handling personal information responsibly.

This Privacy Policy explains the categories of information we collect, how we use and disclose
that information, how long we retain it, and the choices that may be available to you when you
use the FINCAVA platform (the "Platform").

The Platform is intended solely for business users and commercial purchasers.

### 1. Information We Collect

We collect information that you voluntarily provide to us and limited technical information
generated when you use the Platform.

#### Account Information

When you create or maintain an account, we may collect:

- your name;
- company or business name;
- job title;
- business email address;
- telephone number;
- country; and
- buyer type.

#### Sourcing Preferences

You may provide sourcing information such as:

- preferred coffee varieties;
- processing methods;
- quality or cupping-score preferences;
- target purchasing volumes;
- certifications;
- preferred growing regions; and
- budget or pricing expectations, if voluntarily provided.

#### Requests and Communications

When you submit an RFQ, sample request, sourcing request, verification request, or other inquiry,
we collect the information contained in that request.

We may also retain communications exchanged between you and FINCAVA.

#### Technical Information

When you access the Platform, we or our service providers may automatically receive limited
technical information, such as:

- IP address;
- browser type;
- device type;
- operating system;
- access date and time;
- pages viewed;
- session information; and
- basic security or usage logs.

Only include references to analytics data if analytics functionality is actually present in the
codebase. Do not imply the use of advertising analytics, behavioral profiling, or cross-site
tracking unless verified.

#### Payment Information

The Platform does not currently process payments, and FINCAVA does not collect payment-card
information through the Platform.

If the codebase indicates otherwise, flag the inconsistency before completing the task rather than
publishing an inaccurate statement.

#### Sensitive Information

FINCAVA does not intentionally request or collect sensitive personal information through the
Platform. Users should not submit sensitive personal information unless FINCAVA specifically
requests it for a legitimate business or legal purpose.

### 2. How We Use Information

We may use personal information to:

- create, authenticate, and manage accounts;
- respond to inquiries and requests;
- process RFQs, sourcing requests, sample requests, and verification requests;
- identify coffee lots that may match stated sourcing preferences;
- communicate about requested products, services, or transactions;
- provide support;
- administer, maintain, secure, and improve the Platform;
- prevent fraud, misuse, and security incidents;
- maintain business and compliance records;
- establish, exercise, or defend legal claims; and
- comply with applicable legal obligations.

If a user opts in, FINCAVA may also notify that user about coffee lots or sourcing opportunities
that match the user's stated preferences.

FINCAVA currently reviews and initiates these communications manually rather than using fully
automated decision-making to select or contact buyers.

Only retain that final sentence if the repository and documented workflow do not contradict it.
(Per CLAUDE.md and the execution spec: Alert Outreach is manual — admin filters buyers and exports
a CSV for manual outreach, no automated campaign sending. This sentence is accurate and should be
retained.)

### 3. Legal Bases for Processing

Where applicable, including when the European Union General Data Protection Regulation or United
Kingdom GDPR applies, FINCAVA may process personal information based on:

- consent;
- steps requested before entering into a contract;
- performance of a contract;
- compliance with a legal obligation; and
- FINCAVA's legitimate interests in operating, securing, and improving its business and serving
  professional buyers, provided those interests are not overridden by applicable privacy rights.

Where processing relies on consent, consent may be withdrawn at any time. Withdrawal does not
affect processing that was lawful before consent was withdrawn.

Only state that consent timestamps are recorded if the implementation has been verified. If
verified, add: "Where applicable, FINCAVA records the date and time at which consent is provided
or withdrawn." (Verified per the note at the top of this prompt — include this sentence.)

### 4. Cookies and Similar Technologies

The Platform currently uses an essential session cookie or similar authentication technology to
maintain user sessions and keep authenticated users signed in.

FINCAVA does not currently use this essential session technology for targeted advertising or
cross-site behavioral tracking.

If the codebase contains analytics, preference, advertising, or third-party cookies, revise this
section accurately and identify whether a consent-management mechanism is required. Do not conceal
or mischaracterize actual cookie behavior.

### 5. How We Disclose Information

FINCAVA does not sell personal information for monetary consideration.

FINCAVA may disclose information:

- to hosting, infrastructure, authentication, email, communications, security, support, and other
  service providers that process information on FINCAVA's behalf;
- when required by law, regulation, subpoena, court order, or other valid legal process;
- when reasonably necessary to protect FINCAVA, its users, its business partners, or others;
- in connection with a merger, acquisition, financing, reorganization, bankruptcy, sale of assets,
  or similar corporate transaction;
- to professional advisers such as attorneys, accountants, auditors, and insurers; or
- with the user's direction or consent.

Sourcing preferences, purchasing strategies, and budget information are not shared with producers,
cooperatives, or other buyers unless:

- the user authorizes the disclosure;
- disclosure is reasonably necessary to respond to or fulfill a transaction requested by the user;
  or
- disclosure is otherwise required by law.

Do not state categorically that no data is ever shared with producers or cooperatives if request
fulfillment may require sharing buyer identity, specifications, volumes, delivery requirements, or
similar information.

### 6. International Data Transfers

FINCAVA operates from the United States.

If a user accesses the Platform from outside the United States, that user's information may be
transferred to, stored in, or processed in the United States or another jurisdiction in which
FINCAVA or its service providers operate. Privacy laws in those jurisdictions may differ from
those in the user's location.

Where required by applicable law, FINCAVA will use an appropriate legal mechanism or safeguard for
an international transfer of personal information.

### 7. Data Retention

FINCAVA retains personal information for as long as reasonably necessary for the purposes
described in this Privacy Policy, including to:

- provide requested services;
- maintain accounts and transaction records;
- comply with legal, tax, accounting, and regulatory obligations;
- prevent fraud or misuse;
- resolve disputes; and
- enforce agreements.

Retention periods may vary based on the type of information, the relationship with the user,
applicable legal requirements, and FINCAVA's legitimate business needs.

When information is no longer reasonably required, FINCAVA may delete, anonymize, or otherwise
dispose of it in accordance with its operational and legal obligations.

### 8. Privacy Rights and Choices

Depending on the user's location and applicable law, the user may have the right to:

- request access to personal information;
- request correction of inaccurate personal information;
- request deletion of personal information;
- request restriction of certain processing;
- object to certain processing;
- request a portable copy of certain information;
- withdraw consent where processing relies on consent; and
- lodge a complaint with an applicable data-protection authority.

These rights are not absolute and may be subject to legal exceptions.

FINCAVA may request information reasonably necessary to verify the identity and authority of a
person submitting a privacy request.

FINCAVA will not unlawfully discriminate against a user for exercising an applicable privacy
right.

### 9. Account Deletion

A user may request deletion of a FINCAVA account by contacting FINCAVA using the information
below.

After verifying the request, FINCAVA will delete or anonymize personal information associated
with the account unless retention is reasonably necessary or legally required for purposes such as
tax compliance, accounting, fraud prevention, security, dispute resolution, enforcement of
agreements, or the establishment, exercise, or defense of legal claims.

Deletion may remove the user's profile, RFQ history, sample requests, sourcing requests, saved
preferences, and related account information.

Do not describe deletion as immediate, universal, or permanent if backups, legal holds,
transaction records, or technical retention periods prevent that statement from being accurate.
(Per CLAUDE.md: buyer deletion is a real hard delete, cascading to RFQs/samples/sourcing
requests/sessions, confirmed via raw DB assertion. Describe it accurately against that actual
implementation, not more or less broadly than what the code does.)

### 10. Security

FINCAVA maintains reasonable administrative, technical, and organizational safeguards designed to
protect personal information from unauthorized access, acquisition, use, disclosure, alteration,
or destruction.

No method of transmission over the internet or method of electronic storage is completely secure.
FINCAVA therefore cannot guarantee absolute security.

### 11. Children's Privacy

The Platform is intended solely for business users and is not directed to children or individuals
under 18 years of age.

FINCAVA does not knowingly collect personal information from children through the Platform. A
person who believes a child has submitted personal information may contact FINCAVA to request
review and appropriate deletion.

### 12. Third-Party Services and Links

The Platform may contain links to or integrate with third-party websites or services. FINCAVA is
not responsible for the privacy, security, or content practices of third parties that operate
under their own terms and privacy policies.

Only retain this section if the Platform contains or may reasonably contain third-party links or
integrations.

### 13. Changes to This Privacy Policy

FINCAVA may update this Privacy Policy from time to time.

The revised version will be posted on this page with an updated Effective Date. Where required by
applicable law, FINCAVA will provide additional notice of material changes.

Do not state that continued use automatically constitutes consent to all privacy-policy changes.
A privacy policy is generally a notice of practices, and separate consent may be necessary where
applicable law requires it.

### 14. Contact Us

Questions, privacy requests, and complaints may be submitted to:

**FINCAVA**
KR Industries LLC
info@fincava.com

---

## Implementation Requirements

- Preserve the existing legal-page layout and site styling.
- Use semantic HTML or the project's equivalent accessible components:
  - one `h1` per page;
  - `h2` or `h3` headings in logical order;
  - real unordered or ordered lists;
  - readable paragraphs;
  - accessible links.
- Avoid rendering the legal text as one large hard-coded HTML string when the framework supports
  structured components.
- Ensure curly quotation marks and apostrophes do not cause linting, JSX, template, or encoding
  errors.
- Preserve existing SEO metadata where appropriate, but update titles and descriptions to
  accurately identify the pages.
- Confirm the footer and navigation links still resolve correctly.
- Preserve old legal-page routes or add redirects if route names change.
- Do not add a cookie banner unless the site's actual cookies or applicable implementation
  requirements make one necessary.
- Do not add consent checkboxes or change signup flows as part of this content-only task.
- Do not present placeholders as completed business information.
- Do not add "last updated" dates that are not accurate.
- Do not claim compliance certifications or comprehensive compliance with GDPR, CCPA, the Texas
  Data Privacy and Security Act, or any other law.
- Do not change the substantive legal text merely to shorten it unless required by the project's
  rendering constraints.

## Verification

After making the changes:

1. Run the project's existing formatter, linter, type checker, tests, and production build, using
   only commands already supported by the repository.
2. Fix any errors caused by the edits.
3. Inspect both pages at mobile and desktop widths if the repository provides a preview or
   browser-testing workflow.
4. Verify:
   - headings are correctly nested;
   - lists render correctly;
   - no text is clipped or horizontally scrollable;
   - navigation and footer links work;
   - placeholders remain clearly visible where data was unavailable;
   - no existing routes were unintentionally broken.

## Final Response

Provide:

1. a concise summary of the files changed;
2. the routes for both legal pages;
3. any placeholders that remain;
4. any discrepancies discovered between the proposed policy and the site's actual implementation,
   especially relating to: cookies; analytics; authentication; payment processing; email or
   marketing tools; third-party service providers; data collection;
5. the verification commands run and their results;
6. confirmation that the international-buyer clause was merged into Section 9 as instructed, and
   whether anything else in this content conflicted with CLAUDE.md's "Deliberate decisions"
   section.

Do not claim that the pages are legally compliant or attorney-approved. State only that the
requested content was implemented and identify any factual or technical issues requiring business
or legal review.

Once done, update CLAUDE.md's "Deliberate decisions" section to reflect that Terms of Service and
Privacy Policy are now on this full version, so future sessions don't re-flag this content as
pending or attempt to re-derive it.
