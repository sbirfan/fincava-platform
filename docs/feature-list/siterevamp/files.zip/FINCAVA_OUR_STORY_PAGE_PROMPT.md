Add a new public page to the FINCAVA site: "Our Story," a personal founder narrative, separate
from the existing About page (which stays exactly as-is — do not merge, edit, or remove any of its
content as part of this task).

Read CLAUDE.md at the repository root first for design-system facts (sage-and-paper palette,
fc-font-display for headings, fc-font-sans for body, card-based layout patterns) and settled
project decisions. This task adds content only — no schema, API, auth, or business-logic changes.

## Implementation

- New route: `/our-story` (adjust to match existing route-naming conventions if a different
  pattern is established elsewhere in the app).
- New component, e.g. `client/src/pages/OurStory.tsx`, following the same structural pattern as
  the existing `About.tsx` (hero/intro treatment, section headings, card or prose blocks as
  appropriate) so it feels native to the site rather than a bolted-on page.
- Add a nav link to it — place it wherever makes sense given the current nav structure (e.g.
  alongside or nested under the existing About link). Use your judgment on exact placement, but
  don't let it crowd out the primary buyer-facing nav items (Available Lots, Sourcing Request,
  etc.) — this is a narrative/trust-building page, not a primary conversion path.
- Use semantic HTML: one `h1` ("Our Story"), `h2`/`h3` for the subsections in logical order,
  real paragraphs, no large hard-coded HTML string if the framework supports structured
  components.

## Content

Use the exact text below, verbatim — this has already been through several editorial rounds. Do
not paraphrase, shorten, or "improve" it; only handle the technical work of putting it into a
proper page component with correct heading hierarchy.

---

## Our Story

People often ask us why we started FINCAVA.

The honest answer is that we never set out to build a coffee company. We came to Colombia looking
for a different way of life — more determination than certainty, more ideas than experience, and a
belief that if we surrounded ourselves with good people and stayed true to our values, we'd find
our path.

Some ideas worked. Some didn't. That's exactly how we found FINCAVA.

For two years, we ran a coworking space, business incubator, and complimentary coffee shop where
entrepreneurs and small business owners gathered to work and share ideas. The business itself
wasn't the right fit for the location — but it gave us something more valuable than financial
success: relationships. Those relationships introduced us to family-owned coffee farms and
agricultural entrepreneurs whose knowledge had been passed down for generations.

We weren't falling in love with coffee. We were falling in love with the people behind it.

### Before FINCAVA

Irfan spent more than thirty years in the technology industry, the last decade leading
transformation programs for underperforming organizations. The work was never really about
technology — it was about understanding people, solving hard problems, and helping organizations
reach their potential.

Katherine spent years managing medical facilities, learning firsthand where modern healthcare
systems succeed and where they fall short, before leaving to build her own venture. Today,
alongside FINCAVA, she still volunteers her time connecting patients with — and translating for —
a local functional-medicine physician whose food-first approach to healing reflects the same
belief in sustainable, people-centered solutions.

Neither of us realized those experiences were preparing us for FINCAVA. Today, they shape
everything we do.

### What We Believe

The world doesn't have a shortage of exceptional producers. It has a shortage of opportunities
for people to discover them.

Too often, small farms are known only by the commodities they produce, not the families and
expertise behind them. We wanted to help change that — not by changing how they farm, but by
changing how the world discovers them.

### Women First

From the beginning, FINCAVA has been committed to supporting women-led farms and agricultural
businesses.

Not because they need rescuing. They don't. They're experienced producers, business owners, and
leaders in their communities. What many need isn't someone to teach them how to grow better
coffee — they've already mastered that. What they need is greater visibility, trusted
relationships, and access to markets that recognize the value of what they already produce.

That's why we describe FINCAVA as women-first, not women-only. Women-led producers remain at the
heart of our mission, while we also partner with exceptional family farms and small agricultural
businesses that share our commitment to quality, transparency, and stewardship.

### More Than Coffee

Coffee is where our journey begins. Soon, we'll expand into cacao. Over time, we hope to introduce
other agricultural products from producers whose values align with ours.

Whatever the product, our purpose stays the same: help remarkable people reach remarkable markets.

### Just Getting Started

We're at the beginning of our journey. We don't pretend to have decades of experience exporting
agricultural products, and we know there will be challenges — building relationships across
countries, cultures, and supply chains takes time. We welcome those challenges, because each one
is a chance to learn, improve, and better serve the producers and partners who trust us.

Some visitors will choose to work with us today. Others may follow our journey and reconnect in a
year or two. Either is perfectly okay.

Trust isn't something we expect because we have a website. It's something we intend to earn,
through every conversation, every partnership, and every promise we keep.

### Our Vision

We envision a future where exceptional producers are recognized not only for what they grow, but
for who they are — where buyers know the people behind what they purchase, where technology
strengthens relationships instead of replacing them, and where trust is built through
transparency.

We don't believe the future of agriculture is built by changing the people who grow it. We believe
it's built by changing how the world discovers them.

---

**The Bean. The Roast. The Hand. Together, they create every exceptional cup.**

**Grown by the farmer. Crafted by the roaster. Delivered by the hand that serves it.**

---

## Constraints

- Do not touch `About.tsx` or any of its content — these are two separate pages by design.
- Do not add any claim about current business operations, verification services, pricing, or
  logistics capabilities to this page — it's personal narrative only. If anything in the text
  above appears to conflict with a fact in CLAUDE.md's "Deliberate decisions" section, stop and
  flag it rather than resolving it yourself.
- No new dependencies, no schema changes, no route changes beyond adding this one new page.
- SEO: add appropriate title/meta description for this page, distinct from About's.
- Responsive: verify at mobile, tablet, and desktop widths — no clipped text, no overflow, the
  closing tagline block reads cleanly at all three sizes.

## Validation

Run the repository's format/lint/build commands. Confirm the new route renders, the nav link
works, About.tsx has zero diff, and no console errors on load.

Do not commit, push, or deploy — leave this in the local working tree for review, same as prior
copy-review work.

## Report back

Confirm: the route path and nav placement chosen; that About.tsx is untouched (zero diff); build/
lint/validation results; any conflict found against CLAUDE.md's "Deliberate decisions"; and a
screenshot or description of the page at each of the three breakpoints.
