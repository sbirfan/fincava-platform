Item 1 from two rounds ago is still open — it didn't appear in the last report at all (which covered
items 2 and 3, but not 1), even though Phase 3 was reported as closed. Resolve it now before Phase 4.

RATE-LIMIT BUCKET SHARING ACROSS /verification AND THE THREE BUYER FORMS

/verification, RFQ, sample, and sourcing currently all draw from the same 10/hour/IP rate-limit
bucket (confirmed in the Phase 3 report, item 7 — all four import the same limiter instance).
/verification is the only endpoint on the site with no auth wall in front of it. Sharing a bucket
means an anonymous actor hammering /verification from one IP can exhaust the same quota a real
authenticated buyer behind that IP needs for RFQ/sample/sourcing — shared office network, corporate
NAT, whatever the case.

Split /verification into its own independent 10/hour/IP bucket, separate from the three
buyer-authenticated forms (which can continue sharing a bucket with each other, or not — your
call, just make it deliberate).

Prove it with a scripted before/after, both parts required:
1. Before the fix (or by reasoning from the current shared-instance code, if you've already made
   the change and can't easily revert to demonstrate the old behavior): show that exhausting
   /verification's quota from an IP currently blocks that same IP's RFQ/sample/sourcing
   submissions too.
2. After the fix: max out /verification from an IP, then confirm an RFQ/sample/sourcing submission
   from that same IP still succeeds (still has its own untouched quota). Then do the reverse — max
   out RFQ/sample/sourcing from an IP, confirm /verification from that IP still has its own quota.

Report back with the actual request-by-request results (same standard as every prior rate-limit
verification in this project — exact numbers, not "confirmed it works"). Once this is resolved and
verified, give me the actually-final Phase 3 status before I write the Phase 4 kickoff.
