# FINCAVA Platform — Replit & Database Setup Guide

This covers getting the live client-facing site running on Replit, hosting a Neon Postgres
database, and wiring the two together. Development happens against GitHub as the source of
truth (per the execution spec, §2: "GitHub is the source of truth. Replit is used only for
testing, preview, and hosting"); this guide is about turning that GitHub repo into a hosted,
working site — not about where the code gets written.

Note: Replit's exact UI (menu names, panel locations) changes periodically. The steps below are
current as of this writing, but check Replit's own docs if something doesn't match what you see.

---

## Order of operations

Do these roughly in this order — Claude Code needs the Neon connection string before it can run
migrations, and Replit needs a working build before a custom domain is worth configuring.

1. Set up Neon (database)
2. Generate secrets
3. Set up Resend + Cloudinary (you already have accounts per the Handover doc — just pull the
   specific values you need)
4. Hand credentials to Claude Code so it can run the Phase 0 migration and seed
5. Push the working app to GitHub
6. Import the GitHub repo into Replit
7. Configure Replit Secrets with the same environment variables
8. Deploy on Replit, verify the health endpoint
9. Point fincava.com at the Replit deployment

---

## 1. Neon (database)

1. Go to your Neon dashboard → create a new project (name it `fincava-platform` or similar).
2. Once created, go to **Connection Details**. Use the **pooled** connection string (not the
   direct one) — this is what goes in `DATABASE_URL`. It looks like:
   `postgresql://user:password@ep-xxxx-pooler.region.aws.neon.tech/dbname?sslmode=require`
3. Keep this tab open — you'll paste this string into both Claude Code's environment and later
   into Replit Secrets.

## 2. Generate secrets

Run these locally (or ask Claude Code to run them for you) — each must be a distinct random
value, do not reuse one for the other:

```bash
openssl rand -hex 32   # → SESSION_SECRET
openssl rand -hex 32   # → OTP_HASH_SECRET
```

Pick your own value for `ADMIN_PASSWORD` — something you'll actually remember, since it's a
single shared password with no reset flow (per the Handover's auth design).

## 3. Resend and Cloudinary

Per the Handover doc, you already have both accounts set up with a verified Resend sending
domain. Pull these values from each dashboard:

- `RESEND_API_KEY` — Resend dashboard → API Keys
- `EMAIL_FROM` — the verified sender address (e.g. `hello@fincava.com`)
- `FOUNDER_EMAIL` — your personal email for notifications
- `CLOUDINARY_CLOUD_NAME`, `CLOUDINARY_API_KEY`, `CLOUDINARY_API_SECRET` — Cloudinary dashboard

## 4. Hand credentials to Claude Code

Once you have all of the above, give Claude Code the values (locally, in your own `.env` file —
never paste secrets into chat with any AI tool, including this one). Ask it to run the Phase 0
migration and seed script against the real Neon database, then confirm the health endpoint
responds and the seed data loaded. This is the point where Phase 0's exit tests actually get
verified against a real database rather than just reviewed in the abstract.

## 5. Push to GitHub

Standard flow — Claude Code should already be committing and pushing after each phase per the
kickoff prompt. Confirm `git log` shows real history and `.env` is in `.gitignore` (never
committed) before moving on.

## 6. Import the GitHub repo into Replit

Two ways to do this:

- **Fast path (public repo):** in your browser, go to `replit.com/github.com/sbirfan/fincava-platform` — Replit clones it directly into a new App.
- **Guided path:** go to `replit.com/import`, click **Import from GitHub**, authorize your GitHub
  account if you haven't already, and select `sbirfan/fincava-platform`.

Either way, Replit sets up two-way Git sync — commits made in Replit can push back to GitHub, and
you can re-pull from GitHub into the Repl. For this project, treat GitHub as the one-way source
of truth: develop and push from Claude Code, then pull those changes into the Repl rather than
editing directly inside Replit.

## 7. Configure Replit Secrets

Inside the Repl, open the **Secrets** panel (padlock icon in the left sidebar). Add every
variable from `.env.example`, with real values this time:

```
DATABASE_URL
SESSION_SECRET
OTP_HASH_SECRET
ADMIN_PASSWORD
RESEND_API_KEY
EMAIL_FROM
FOUNDER_EMAIL
CLOUDINARY_CLOUD_NAME
CLOUDINARY_API_KEY
CLOUDINARY_API_SECRET
```

These are injected as environment variables at runtime — the app reads them via `process.env`
exactly the same way it would locally. Do not put any of these in a committed file.

## 8. Deploy on Replit

1. Open the **Deployments** pane.
2. Choose a deployment type. For FINCAVA, **Autoscale** is the right fit — the app has no
   in-memory state (sessions live in Postgres, not in the Node process), so it can scale down to
   zero between requests without losing anything. Reserved VM is unnecessary cost for this
   traffic profile unless you specifically want an always-on instance.
3. Set the build command to `npm run build` and the run command to `npm start` (matching the
   scripts Claude Code set up in Phase 0).
4. Click **Deploy**. You'll get a working `*.replit.app` URL — confirm the health endpoint
   responds and you can browse the seeded lots before moving to the domain step.

## 9. Point fincava.com at Replit

1. In the Deployments pane, go to **Settings** → the domain-linking section.
2. Enter `fincava.com` (and `www.fincava.com` if you want both). Replit will generate an A record
   and a TXT record specific to your deployment.
3. Log into your domain registrar (wherever fincava.com is registered) and add those exact
   records under DNS settings.
4. DNS propagation can take anywhere from a few minutes to 48 hours. Return to the Replit
   Deployments pane to verify once it's propagated — it'll show as verified when ready.

---

## After launch

- Re-deploying: after Claude Code pushes new commits to GitHub, pull them into the Repl, then
  redeploy from the Deployments pane. This isn't automatic unless you separately configure a
  CI/CD trigger — for a single-founder operation, manual redeploy after each meaningful change is
  simpler and safer than automating it.
- Backups: the README (per execution-spec §11) should document the exact `pg_dump` command
  against your Neon connection string. Run it weekly, store it somewhere outside of Replit and
  Neon both.
- If a Secrets value ever needs to change (e.g., rotating `ADMIN_PASSWORD`), update it in the
  Replit Secrets panel and redeploy — there's no separate "restart" needed beyond that.
