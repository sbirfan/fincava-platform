Phase 2 is closed. Start Phase 3 (RFQ + samples + sourcing requests) per execution-spec §5 and §10.

SCOPE

1. RFQ form + endpoint — auth-required, lot-linked, prefilled from the buyer's profile
   (name/company/email/country). Fields per §5 rfqs table.
2. Sample request form + endpoint — auth-required, lot-linked, only offered when the lot's
   sampleAvailable is true. Fields per §5 sampleRequests table.
3. Sourcing request form + endpoint — auth-required, standalone (NOT lot-linked). Follow the §5
   UX guidance exactly:
   - Structured fields for what buyers always know; free-form additionalNotes for everything else.
   - Every structured select includes an "open to suggestions" / "no preference" option.
   - maxBudgetPerKg is optional, labeled as confidential, never shared with producers.
   - No screen size, moisture, water activity, or incoterm fields (explicitly excluded — see §5).
   - No file uploads.
   - Form intro copy and the confirmation email must both state this is not a guarantee — use the
     exact language from §5/§8: "We'll search our network of Colombian cooperatives and farms and
     respond within 10 business days with available options — or let you know if we can't match
     your requirements right now."
4. "Can't find what you need?" CTA on the catalog and lot passport pages, linking to the sourcing
   request form, visible to authenticated buyers.
5. CLOSE OUT THE STANDING TODO: the Home page's second hero CTA currently points to /verification
   as a tracked Phase-3 stopgap (TODO(Phase 3) comment + README "Tracked TODOs" entry, commit
   c0eb00e). Now that the sourcing request form exists, revert that CTA to point to it, and remove
   the TODO from both the code comment and the README section. Confirm both are actually gone, not
   just the CTA link changed.
6. Buyer confirmation emails for all three request types, using the existing email utility
   (server/src/email/send.ts) — do not build a second email path. RFQ and sample confirmations:
   "We respond within 2 business days" (§8). Sourcing confirmation: the not-a-guarantee language
   from item 3 above.
7. Founder notification emails for all three types, fired on every new submission, with a summary
   and a link to the admin record. (The admin record itself still sits behind the Phase-4 stopgap
   Bearer auth confirmed in Phase 2 — that's expected and unchanged, not a regression to fix now.)
8. Buyer request history on My Profile — all three types, with correct status per type
   (request_status for RFQ/sample, sourcing_status for sourcing).
9. Rate limiting (10/hour/IP, same as the verification form) and honeypot fields on all three
   forms, per §9.
10. zod validation on all three new endpoints — strict, reject unknown fields, same discipline as
    every prior endpoint.

EXIT TESTS — SAME REPORTING STANDARD AS PHASE 1 AND 2: PER-ITEM EVIDENCE, NOT A SUMMARY CLAIM

- Anonymous submission rejected at the API level for all three form types — test with a real
  unauthenticated HTTP request per endpoint, not a stub.
- Submissions persist with correct foreign keys (buyerProfileId, lotId where applicable).
- All three confirmation emails and all three founder notifications fire. Confirm via Resend
  logs/message IDs for all six. Additionally, physically confirm delivery (actual inbox, not just
  Resend's "sent" status) for at least the sourcing confirmation to the buyer and one founder
  notification — the sourcing template has compliance-sensitive language that needs to be seen
  correctly rendered in a real inbox, not just logged as sent.
- Sourcing request confirmation email contains the exact not-a-guarantee language, verified by
  reading the actual sent content, not just confirming the email fired.
- A Resend outage/misconfiguration does not fail the user's submission (same non-blocking pattern
  already proven in Phase 1/2 — re-verify it holds for these three new endpoints specifically,
  don't assume it carries over untested).
- Request history on My Profile shows correct status per type, for all three.
- Rate limit triggers at the exact configured boundary — same rigor as Phase 2 item 6: state the
  limit, show the request number where it actually blocks, don't just confirm "it blocks
  eventually."
- Honeypot rejects silently (200/201 response shape, zero DB row) on all three forms.
- Sourcing request "no preference" / "open to suggestions" option works for every structured
  field — enumerate which fields you tested, don't assert this generically.
- maxBudgetPerKg is optional and submits correctly both when provided and when left empty.
- Sample request form correctly refuses (or hides) the option when the target lot's
  sampleAvailable is false.

Commit and push after the phase is fully verified. Report back per-item, with the same evidence
standard as the Phase 2 corrected report, before Phase 4 starts.
