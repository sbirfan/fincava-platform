Small, standalone fix before anything else — do not bundle this with the copy-review diff still
sitting in the working tree.

CLAUDE.md's "Current status" section contains a stale paragraph left over from before a later
commit added the international-buyer acknowledgment clause to Terms.tsx. It currently implies that
clause doesn't exist, which contradicts the "Deliberate decisions" section above it (which
correctly states the clause is present and finalized).

Fix: update the stale "Current status" paragraph so it no longer contradicts "Deliberate
decisions." Reflect the actual current state accurately — Phases 0–4 closed, Phase 5 closed
(governing-law/business-use/international clauses, contact fixes, fail-fast shared-package guard,
final legal-pages replacement all done), and the copy-review task's diff currently sitting
uncommitted in the working tree, pending review.

Make this a separate, clearly labeled commit on its own — do not combine it with the copy-review
changes when those get committed. This is a project-memory correction, not part of that diff.

Confirm the fix, show the corrected paragraph, and confirm it no longer conflicts with "Deliberate
decisions" anywhere else in the file.
