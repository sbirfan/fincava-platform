# Claude Code Follow-Up Task: Address FINCAVA Copy-Review Findings and Validate User Journeys

You are working in the existing local checkout of `sbirfan/fincava-platform`.

A prior editorial pass has already modified the working tree. Do not discard, reset, overwrite, or
broadly redo that work. Review the current uncommitted diff first, then make only the targeted
revisions and validation work described below.

Do not commit, push, open a pull request, deploy, or modify Git history.

This document also folds in the standalone CLAUDE.md documentation fix that was previously sent
separately — **check first whether that fix was already applied and committed** (look at recent
git log and the current state of CLAUDE.md's "Current status" section). If it's already correct,
skip re-doing it and just confirm it in your report. If not, Finding 5 below covers it in full.

## Objective

Address each outstanding finding from the editorial review:

1. Reconsider and revise the categorical statement that FINCAVA is "not an independent third
   party."
2. Review replacements of "verified" to ensure the new wording remains precise, natural, and
   commercially useful.
3. Improve any weak "documented lots" and "known cooperatives" phrasing where better
   evidence-based language is available.
4. Improve generic admin errors where they can become meaningfully actionable without exposing
   internal details.
5. Correct the stale factual contradiction in CLAUDE.md as a separate, minimal documentation
   correction (if not already done — see note above).
6. Execute all available automated validation.
7. Perform a documented manual verification of the key buyer and admin journeys affected by the
   copy changes.
8. Add narrowly scoped automated tests only if the repository already has a suitable test
   framework or if a minimal test setup can be introduced without disproportionate scope. Do not
   add a large testing framework solely for this follow-up.

The final result should preserve the strengths of the prior editorial pass while resolving the
remaining semantic and validation concerns.

## Step 1: Inspect Current State Before Editing

Read:

- CLAUDE.md
- README.md
- all relevant files under `docs/`
- the full current git diff
- all changed files from the prior copy pass
- route and email-template files related to quote, sample, sourcing, and verification requests

Confirm:

- which files currently use "independent";
- which files currently use "verified," "documented," "known," or equivalent terms;
- where generic admin fallback messages remain;
- the exact stale contradiction in CLAUDE.md, and whether it's already been fixed;
- whether a test framework or test scripts exist now;
- whether Playwright, Cypress, Vitest, Jest, React Testing Library, or another browser/unit test
  tool is already installed.

Do not begin editing until this inventory is complete.

## Finding 1: Replace the Categorical "Not Independent" Statement

### Problem

The prior pass added language stating that FINCAVA is "not an independent third party" because
verification is a FINCAVA revenue line.

That conclusion is too categorical. A paid service can still use objective methods or provide an
impartial factual report in some contexts. The repository establishes that FINCAVA provides the
service commercially, but it does not establish every possible dimension of independence,
conflict, personnel separation, or methodology.

### Required revision

Remove categorical statements that broadly declare FINCAVA or its verification work "not
independent." Use precise limitation language instead.

Preferred baseline wording:

> FINCAVA provides field verification and documentation as a paid service. It is not a
> certification, accredited audit, legal due-diligence opinion, or guarantee. Where relevant,
> FINCAVA will disclose any known commercial relationship connected to the subject of the
> verification.

Adapt this wording to the available layout and context. Do not force the exact sentence into
every location if a shorter version is appropriate.

For the verification page, explain that:

- FINCAVA gathers and reports field observations and available documentation;
- the service is fee-based;
- reports distinguish direct observations, producer-provided information, records reviewed, and
  items that could not be confirmed;
- the work is not certification, an accredited audit, a legal opinion, or a guarantee;
- relevant known commercial relationships should be disclosed where applicable.

For confirmation screens and emails, keep the disclaimer concise.

Do not claim that FINCAVA is independent, impartial, conflict-free, accredited, certified, or
legally qualified unless the repository proves that claim.

Do not invent a formal conflict-of-interest policy.

If disclosure of known commercial relationships is not operationally supported or appears
inconsistent with project documentation, flag it for business review rather than silently
promising it.

## Finding 2: Audit Every Replacement of "Verified"

Search the current working tree for: verified, verification, documented, known, traceable,
observed, confirmed, validated, reviewed.

Classify every remaining use.

"Verified" may remain only where the underlying system or process clearly supports it, such as a
one-time authentication code being verified.

Do not use "verified" broadly for: all lots; all farms; all cooperatives; all producer claims;
every cup score; every certification; general sourcing relationships.

Choose the most specific phrase supported by the data, such as: traceable lot; identified farm or
producer group; documented origin information; available origin and processing information;
FINCAVA-observed information; producer-reported information; third-party certification listed for
the lot; known sourcing relationship; direct working relationship; lot information reviewed by
FINCAVA; information available in the lot passport.

Do not mechanically replace every use with the same word.

## Finding 3: Improve "Documented Lots" and "Known Cooperatives"

Locate each use and determine what the surrounding code and data actually support.

For the home-page buyer proposition, where supported by lot-passport data, prefer concrete
language such as:

> Browse traceable Colombian green-coffee lots with available origin, processing, sensory,
> physical, and commercial information.

Shorter acceptable form:

> Browse traceable lots with available origin, process, quality, and commercial information.

Do not claim all fields are present for every lot. Use "available" where data completeness
varies.

For cooperative and farm relationships, prefer one of these, depending on the documented
relationship: farms and producer organizations FINCAVA can identify and contact; established farm
and cooperative relationships; known sourcing partners; identified farms, cooperatives, and
producer groups; direct working relationships with farms and producer organizations.

Do not use "direct" universally if intermediaries may sometimes be involved. Do not use
"established" if the repository only proves initial contact.

In the final report, list every material wording decision made in this audit and the supporting
repository fact.

## Finding 4: Improve Generic Admin Errors

Review admin-only fallback text such as: Failed to load, Save failed, Delete failed, Update
failed, and similarly terse generic messages.

Make errors actionable and context-specific where the component knows the failed operation.
Examples:

- Could not load requests. Refresh the page and try again.
- Could not load buyer records. Refresh the page and try again.
- Changes could not be saved. Review the form and try again.
- The lot could not be deleted. It may be linked to existing requests.
- The request status could not be updated. Try again.
- The CSV could not be generated. Review the filters and try again.

Where the API returns a safe, user-oriented message, preserve it. Where the API may return
internal implementation details, use a safe fallback. Do not change business logic or expose
internal error details.

## Finding 5: Correct the Stale CLAUDE.md Contradiction

**First check whether this was already fixed** by a standalone task sent earlier. If CLAUDE.md's
"Current status" section already accurately reflects the state below and no longer contradicts
"Deliberate decisions," skip to confirming that in your report. Otherwise, apply this fix now:

Verify the contradiction directly against CLAUDE.md, `client/src/pages/Terms.tsx`, and current
repository history only if necessary.

CLAUDE.md's "Current status" section contains a stale paragraph left over from before a later
commit added the international-buyer acknowledgment clause to Terms.tsx. It currently implies that
clause doesn't exist, which contradicts the "Deliberate decisions" section above it (which
correctly states the clause is present and finalized).

Make the smallest possible documentation-only correction so CLAUDE.md accurately describes the
current implementation: Phases 0–4 closed with verified exit-test evidence; Phase 5 closed
(governing-law/business-use/international clauses in Terms.tsx, Contact.tsx fixes, the
fail-fast shared-package startup guard, and the full legal-pages replacement all complete); and
note that a subsequent copy-review pass (this one, plus its predecessor) has since been applied on
top of the closed Phase 5 work.

Requirements:

- edit only the stale sentence or paragraph;
- do not reformat unrelated parts of CLAUDE.md;
- do not change legal application code as part of this correction;
- keep the change in a distinct diff hunk;
- mention it separately in the final report as a project-memory correction, not part of the copy
  diff.

## Finding 6: Manual Verification of Key Journeys

Because the repository reportedly has no automated test suite, execute a structured manual
validation.

Use the local application if environment configuration permits. If required environment variables
or services prevent the full application from running: do not fabricate results; identify the
precise blocker; still complete static, build, and component-level checks where possible.

### Buyer-facing journeys

**Anonymous home and lot discovery** — home-page value proposition; absence of unsupported
"verified" or "independent" claims; available-lot card text; formatted statuses; available-lots
empty/filter state; lot-passport locked state; registration CTA; sourcing-request fallback.

**Authentication** — sign-in/register wording; email-code explanation; code-expiration copy;
anti-enumeration behavior remains unchanged; "verified" is used only for the code where
appropriate.

**Quote request** — form, success state, and transactional email: field labels; lot context;
2-business-day commitment; review of volume, destination, Incoterm, delivery timing, availability,
and commercial terms; no promise of inventory reservation; no implication of a binding quotation.

**Sample request** — form, states, and transactional email: authentication gate; unavailable-sample
state; form labels; 2-business-day commitment; review of availability and shipping information; no
implication that a sample has been approved or shipped.

**Sourcing request** — form, success state, and transactional email: 10-business-day commitment;
protected no-guarantee language remains unchanged where explicitly locked; budget is clearly
labeled in USD, consistent with schema and route behavior; available-match, follow-up-question,
alternative, and no-match expectations remain accurate.

**Verification request** — form, success state, and transactional email: 5-business-day
commitment; five days clearly refers to scoping and response, not fieldwork completion; revised
non-categorical service disclaimer (per Finding 1); feasibility, scope, access, deliverables,
timing, and pricing expectations; no promise that the request will be accepted; no certification,
accredited-audit, legal-opinion, or guarantee implication.

**Profile** — welcome banner; account-unlock explanation; alert versus marketing consent
distinction; save success and error messages; request-history empty states and labels.

**Contact, 404, and unexpected-error states** — contact details remain unchanged; contact routing
text is accurate; 404 next action; error-boundary next action; no internal technical information
is exposed.

### Admin journeys

At minimum inspect or run: admin sign-in; dashboard labels; lot status labels; pricing-strategy
labels; request-type and request-status labels; buyer detail labels; market-intelligence helper
text; alert-outreach helper text; improved error fallbacks (per Finding 4). Confirm raw enum
values are not displayed where polished labels are expected.

### Responsive inspection

Inspect representative public forms and admin pages at approximately 375px mobile, 768px tablet,
1280px desktop. Check for: text wrapping; clipped buttons; overflowing labels; excessively wide
confirmation paragraphs; unreadable status pills; broken navigation.

Use browser automation or screenshots only if the repository already supports them. Otherwise
document a careful manual browser inspection.

## Finding 7: Automated Tests

First use existing test infrastructure if present.

Add narrowly targeted regression tests for:

- Verification copy does not contain "not an independent third party."
- Verification copy includes appropriate service limitations.
- Home and lot copy do not broadly call lots, farms, or cooperatives "verified."
- Quote confirmation contains "2 business days" and does not claim inventory is reserved.
- Sample confirmation contains "2 business days" and does not claim approval or shipment.
- Sourcing confirmation contains "10 business days."
- Verification confirmation contains "5 business days" and distinguishes scoping/response from
  service completion.
- Budget label includes USD where the route and schema hardcode USD.
- Admin status labels render polished text instead of raw enums.
- Legal files remain unchanged except for the intentional CLAUDE.md correction.

If no test framework exists, do not add a large framework solely for this task. Instead, create a
lightweight validation script only if it adds real value and fits existing tooling. A
dependency-free Node or TypeScript script under `scripts/` is acceptable.

A lightweight copy-validation script may assert: required response-time strings exist; prohibited
categorical wording is absent; protected sourcing language remains byte-identical or matches its
expected constant; prohibited broad phrases such as "verified lots" are absent; Terms and Privacy
files have no unintended diff; expected admin-label mappings exist.

Do not make brittle assertions against every sentence.

**If you create this script, keep it** — the upcoming UX/form-enhancement work (phased separately)
will touch many of these same confirmation strings and admin labels, and re-running this script
after each of those phases is a cheap way to catch the same class of regression (a "verified lots"
or "independent" phrase creeping back in, a response-time figure drifting) before it ships. Note
in your report that it should be re-run in that context, not just this one.

## Validation Commands

Run the repository's actual scripts. At minimum:

```bash
npm run lint
npm run build
```

For formatting: run Prettier only on files changed in this follow-up; do not run a repository-wide
formatter if it would create unrelated diffs; report the exact scoped command.

Also run: existing tests, if available; the new lightweight validation script, if created;
`git diff --check`; stale-pattern search; raw-enum display search; prohibited-claim search.

Suggested searches:

```bash
rg -n -i "not an independent third party|verified lots|verified farms|verified cooperatives|no intermediaries"
rg -n "Failed to load|Save failed|Delete failed|Update failed" client/src/pages/admin client/src/components
rg -n "2 business days|5 business days|10 business days" client/src server/src
rg -n "Phase 4|admin dashboard ships" .
```

Adjust commands for the actual repository structure.

## Diff-Safety Requirements

Before completion, confirm:

- no dependencies changed unless explicitly justified;
- no migrations or schemas changed;
- no API contracts changed;
- no routes changed;
- no response-time commitments changed;
- no protected sourcing string changed unintentionally;
- Contact constants remain unchanged;
- Terms.tsx and Privacy.tsx have zero diff;
- the CLAUDE.md edit is limited to the stale factual contradiction (or already-fixed and merely
  confirmed);
- no unrelated formatting changes exist;
- no commit, push, PR, or deployment occurred.

## Required Final Report

Return a structured report with these sections:

### Summary

Describe the targeted findings addressed.

### Finding-by-finding resolution

For each finding, state: original concern; files reviewed; exact resolution; why the new wording
or behavior is more accurate.

### Verification terminology audit

List every remaining material use of: verified; independent; documented; known; traceable. Explain
why each use is supported.

### Admin error improvements

List each generic error replaced and its new actionable message.

### Documentation correction

Summarize the stale CLAUDE.md statement and the corrected wording, or confirm it was already fixed
by the standalone task and needed no further change.

### Automated validation

List exact commands and outcomes for: formatter; lint; build; tests; copy-validation script, if
added; `git diff --check`; search commands.

### Manual journey verification

Provide a concise matrix showing: journey; state tested; result; blocker, if any; evidence or
observation. Include all four request flows and email templates.

### Responsive verification

Report mobile, tablet, and desktop results.

### Files changed

Separate: product copy changes; admin error changes; documentation-only changes; test or
validation-script changes.

### Remaining risks or uncertainties

Call out unresolved policy questions, especially: conflict or commercial-relationship disclosure
policy for verification; precise meaning of traceability; completeness of lot documentation;
whether verification reports follow a standard methodology.

### Final repository state

Confirm explicitly: nothing committed; nothing pushed; no pull request opened; nothing deployed.

## Completion Standard

Do not declare completion merely because lint and build pass. The task is complete only after:

- every finding is resolved or explicitly blocked;
- verification terminology is audited context by context;
- confirmation screens and email templates are checked;
- admin errors are more actionable where appropriate;
- the CLAUDE.md contradiction is corrected minimally (or confirmed already correct);
- available automated tests or lightweight validations have run;
- manual journey verification is documented;
- the final diff is reviewed for scope and semantic accuracy.
