Two related changes: hide the seed lots from production, and replace the resulting empty catalog
with an honest state instead of a misleading one.

Read CLAUDE.md first for context and settled decisions. This task doesn't add new scope beyond
what's below — no new database tables, no new anonymous-capture mechanism (a "notify me" email
signup was considered and explicitly declined for now; don't add one).

## 1. Hide the seed lots in production

The 6 seed lots from Phase 0 (covering all five pricing strategies) are currently visible in the
live production database and represent real-looking coffee that doesn't actually exist yet as
current FINCAVA inventory. Set `visible=false` on all of them in the production Neon database —
do not delete them. They should remain in the database and visible/editable in the admin Lots
screen (admin can already see non-visible lots per the existing spec), just not shown to public or
buyer-facing views.

Do this as a direct, one-time data change (a script or a manual admin action — your call on the
cleanest approach), not a schema or code change. Confirm afterward, querying production directly,
that all 6 seed lots now have `visible=false` and that the public lot-list endpoint returns zero
lots.

## 2. Build an honest "no lots yet" empty state — distinct from the existing filter-empty state

There are two different empty states that need to stay distinct — don't collapse them into one:

- **Existing state (keep as-is):** a buyer applies filters and no lots match those specific
  filters, while other lots do exist. This should continue to suggest clearing filters, same as
  today.
- **New state (build this):** there are zero visible lots at all, regardless of filters — the
  catalog is genuinely empty. This needs different copy, since telling someone to "clear filters"
  when nothing exists at all would be confusing. Check which case applies (zero total visible lots
  vs. zero lots matching the current filter) and show the correct one.

For the new "catalog is genuinely empty" state, use this copy on both the Available Lots page and
the Home page's featured-lots section:

> **No lots listed yet**
> FINCAVA is newly launched and actively sourcing its first Colombian lots. Submit a sourcing
> request and we'll follow up directly as inventory becomes available.

Primary CTA: **Submit a Sourcing Request**.

- For an authenticated buyer, link directly to the sourcing request form, same as the existing
  "Can't find what you need?" CTA already used elsewhere on the site.
- For an anonymous visitor, since sourcing requests require an account, route them through
  whatever the site's existing pattern is for an anonymous visitor hitting an auth-gated CTA
  (check how the current "Can't find what you need?" flow or similar gated CTAs handle this
  elsewhere in the codebase, and reuse that same pattern rather than inventing new behavior). Do
  not add a new anonymous notification-signup mechanism — direct them toward registration and the
  sourcing request flow only.

Match the existing empty-state visual treatment already used elsewhere on the site (same card/
illustration/spacing pattern as the filter-empty state and other empty states built in earlier
phases) rather than designing a new visual style for this one.

## Constraints

- No schema changes, no new tables, no new API endpoints beyond what already exists.
- Do not touch RFQ, sample, sourcing, or verification request logic.
- Do not delete the seed lots — hide only, and confirm they remain admin-editable.
- No new dependencies.

## Validation

- Confirm production shows zero public lots after the visibility change.
- Confirm the Available Lots page and Home page both show the new copy correctly when zero lots
  are visible.
- Confirm the existing filter-empty state still works correctly if you temporarily unhide one seed
  lot for testing (then re-hide it before finishing).
- Run format/lint/build. Check mobile/tablet/desktop rendering of the new empty state.
- Do not commit, push, or deploy — same as prior work, leave everything in the local working tree
  and the production data change confirmed via direct query, for review before anything is
  finalized.

## Report back

Confirm: the production visibility change and a query proving zero public lots remain; which
existing gated-CTA pattern was reused for the anonymous-visitor case and where it was found in the
codebase; validation results; and screenshots or descriptions of both empty states (genuinely-empty
vs. filtered-to-empty) so I can confirm they're visually distinct and both correct.
