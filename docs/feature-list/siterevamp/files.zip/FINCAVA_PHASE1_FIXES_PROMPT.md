Before starting Phase 2, three items from the Phase 1 report need to be resolved — one is a
likely real bug, not just a loose end.

1. RATE LIMIT NUMBER MISMATCH — ROOT-CAUSE THIS, DON'T RE-CHECK THE BOX

The report says the spec's rate limit is 10/hour/IP, but the scripted test showed requests 1–7
succeeding and 8–10 getting 429. If the limit were actually 10, request 11 should be the first
one blocked, not request 8. This was marked ✅ but the numbers don't support that.

Find out which of these is true and fix accordingly:
- The rate limiter is configured for 7 (or some other wrong number) instead of 10 — likely a
  copy/paste or off-by-N error in the middleware config. Fix the configured value to match the
  spec's 10/hour/IP.
- Or the test script has its own off-by-three error and the limiter is actually correct — in
  which case fix the test, not the limiter.

Don't just confirm "some requests get blocked eventually." Re-run the scripted test and confirm
requests 1–10 succeed and request 11 is the first 429, with correct RateLimit-*/Retry-After
headers. Report the specific line/value that was wrong and what you changed.

2. CONFIRM REAL EMAIL DELIVERY BEFORE BUILDING ANYTHING ELSE ON TOP OF THE EMAIL UTILITY

RESEND_API_KEY, EMAIL_FROM, and FOUNDER_EMAIL are now set in .env. Using the existing
server/src/email/send.ts utility:
- Submit a real verification request through the actual form/endpoint (not a unit test calling
  the function directly) and confirm both emails actually arrive: the requester confirmation and
  the founder notification. Check the Resend dashboard/logs to confirm delivery, not just that
  the function returned without throwing.
- If either doesn't arrive, debug it now — domain verification, from-address mismatch, API key
  scope, whatever it is — and don't move on until both are confirmed delivered end-to-end.

This matters more than it did for verification alone: Phase 2's OTP flow depends on this same
utility, and a silently-failing OTP email means a buyer with no way to log in. Get this fully
confirmed now rather than carrying it as an open item into Phase 2.

3. HOUSEKEEPING — TRACKED TODO FOR THE STOPGAP CTA

The Home page's second hero CTA currently points to /verification as a stopgap since Sourcing
Request doesn't exist yet. Add an explicit, visible TODO (code comment referencing "Phase 3:
revert to Sourcing Request form" at minimum, or a tracked issue if you're using GitHub issues)
so this doesn't accidentally ship as permanent. Confirm it's tracked somewhere I can see it
before Phase 3 starts, not just mentioned in a chat report.

Report back per item (not a summary): what was actually wrong with the rate limit and what you
changed, confirmation that both verification emails were independently verified as delivered
(not just sent-without-error), and where the CTA TODO is tracked. Once all three are resolved,
give me the corrected Phase 1 exit test report before I write the Phase 2 kickoff.
