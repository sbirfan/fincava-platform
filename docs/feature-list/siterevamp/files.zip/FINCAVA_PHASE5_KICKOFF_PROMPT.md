Phase 4 is closed. Start Phase 5 (Polish + deploy) per execution-spec §10 and §11, plus the items
below carried over from the Phase 4 follow-up.

CONTENT FIXES — CLOSE OUT THE TWO REMAINING PLACEHOLDERS

1. client/src/pages/Contact.tsx — replace the placeholder phone number entirely:
   - WhatsApp: 512-360-0118
   - Email: info@fincava.com
   Confirm both are correct in the rendered page, not just the source.

2. client/src/pages/Terms.tsx — replace the bracketed governing-law placeholder with this final
   clause (confirmed by the founder, this is settled copy, not a placeholder):

   "These Terms, and any dispute arising out of or relating to the Platform or these Terms, are
   governed by the laws of the State of Texas, without regard to its conflict-of-laws principles.
   The parties agree that any such dispute shall be brought exclusively in the state or federal
   courts located in Williamson County, Texas, and each party consents to personal jurisdiction
   and venue there."

   Re-run the full placeholder-text grep from the last round ([X], TODO/TBD/FIXME/lorem-ipsum/
   placeholder, "pending confirmation/sign-off") across the whole repo one more time and confirm
   zero hits remain in buyer-facing copy or email templates. Both the WhatsApp/email fix and this
   clause should now clear that bar for the first time.

FAIL-FAST SHARED-PACKAGE GUARD (Replit's task #13 — implement the "fail fast with a clear error"
option, not the "silently keep running" option)

This crash has happened twice: a stale or missing @fincava/shared build causes a cryptic
SyntaxError at import time and every route 500s. Do NOT implement this as "auto-rebuild and
silently continue" — a missing export from the shared package is a real integrity risk (client and
server could disagree about validation or pricing logic), so masking it and continuing in a
degraded state would be worse than the current loud crash, just quieter.

Implement a startup check instead: on server boot, verify @fincava/shared's compiled output
actually exports everything the server imports from it (or verify a build freshness marker —
whatever mechanism is cleanest given the current build setup). If anything is missing or stale,
exit immediately with a clear, specific error naming exactly what's missing or stale and what
command fixes it (e.g. "FATAL: @fincava/shared build is missing export X — run npm run build
--workspace shared") — not a bare SyntaxError, and not a silent continue.

Separately, confirm (you may have already covered this in the Phase 3 dev-script fix, verify
rather than assume): does npm run start — the actual production path used by the Replit
Deployment — already guarantee a fresh shared build before starting, the same way npm run dev
was fixed to? If not, fix that too; the startup check above is a safety net, not a substitute for
the build itself being correct.

Test this by deliberately staling the shared build (delete shared/dist or remove an export) and
confirming: (a) the new check catches it with the clear error message described above, exits
non-zero, and does NOT serve any routes in a broken state; (b) after rebuilding correctly, startup
proceeds normally. Report both results.

If Replit's own agent executes any part of this task directly inside the Repl rather than through
you, make sure the result still lands as a real commit pushed to GitHub — same source-of-truth
discipline as everything else in this project, not a change that only exists in Replit's
workspace.

POST-REDEPLOY SMOKE TEST — ADD TO README

Add one more line to the "Deploying" section added last round, right alongside the "redeploy
manually after every push" step: after every redeploy, manually confirm the live site actually
works — hit a known real page (e.g. the catalog or a specific lot passport), not just confirm the
deploy succeeded — since App Monitoring only catches a fully-down deployment, not a stale-but-
still-responding one. Make this as explicit and hard-to-skip as the redeploy step itself.

STANDARD PHASE 5 SCOPE (§10, §11)

- Empty states, 404/error pages, loading states.
- SEO meta + OpenGraph per lot, favicon.
- Final README per §11: project purpose, clean-break statement, stack, setup from zero, dev/
  build/run commands, Replit deploy steps (including the two items above), founder operations
  guide (add/edit a lot with images, handle an RFQ/sample/sourcing/verification request end-to-
  end, record market intelligence, run alert outreach, handle a GDPR deletion request, weekly
  pg_dump backup command), what remains manual by design, future-cacao note.
- Final security pass against the full §9 checklist.
- Sanity-check that Replit Publishing access is still set to Public (confirmed once already, but
  re-verify immediately before this phase's final walkthrough, since there's no audit trail if it
  gets changed).
- Full manual walkthrough of the buyer journey (§1) on the live deployed URL — browse anonymously,
  register, unlock passport, submit each of the four request types, confirm emails arrive.

EXIT TESTS

- Full walkthrough of the buyer journey completes cleanly on the deployed URL.
- Founder can complete every admin task without touching code.
- README is accurate from a cold start — ideally verified by literally following it.
- Backup command produces a restorable dump — actually test a restore, not just that the dump
  file is created.
- Placeholder-text grep returns zero hits anywhere in buyer-facing copy or email templates.
- Fail-fast shared-package guard tested per the instructions above.
- Replit Publishing confirmed Public immediately before sign-off.

Report back per-item, same evidence standard as every prior phase. This is the last phase — once
it's closed, the project is done, so hold the same rigor here as everywhere else, not a lighter
pass because it's "just polish."
