Before this session gets compacted, do two things in order: commit the accumulated work properly
separated, then bring CLAUDE.md fully up to date so the next session (post-compact or a fresh one)
has accurate durable memory instead of stale notes.

1. COMMIT THE PENDING WORK — SEPARATED, NOT ONE GIANT COMMIT

Review `git status` and `git diff` to see everything currently uncommitted. Split it into logical
commits along these lines (adjust if the actual diff doesn't cleanly divide this way, but don't
default to one commit for everything):

- The first copy-review pass (public/buyer copy, forms, auth, contact, admin labels, email
  templates from that round).
- The copy-review follow-up (Finding 1's revised verification disclaimer, the "verified"/
  "documented"/"known" audit changes, the 18 admin error message improvements).
- `scripts/validate-copy.mjs` as its own commit (new tooling, not content).
- The CLAUDE.md correction(s) as their own commit, separate from all of the above — this has been
  the standing rule throughout this project (project-memory corrections get their own trail,
  separate from the content/code changes they document).

Use clear, specific commit messages — not "misc copy updates."

Do not push. Local commits only, same as every other checkpoint in this project — pushing and
deploying is still a separate, deliberate step for later.

2. BRING CLAUDE.MD FULLY CURRENT BEFORE COMPACTING

Update CLAUDE.md's "Current status" and "Deliberate decisions" sections to reflect everything
settled across both copy-review rounds:

- The verification page's disclaimer is finalized: fee-based, not certification/audit/legal-
  opinion/guarantee, the four-way observed/producer-reported/reviewed/unconfirmed distinction, and
  a factual (not categorical) statement that FINCAVA has a commercial interest in some verified
  coffee via its other revenue line — explicitly NOT the phrase "independent third party" in any
  form, and explicitly not claiming independence either way.
- Item 5 (per-request commercial-relationship disclosure) is a known, deliberately incomplete
  gap — the page states the general structural fact but there's no schema field or admin workflow
  for a per-request check. This is a pending business decision, not a bug — note it as such so a
  future session doesn't either "fix" it by inventing a workflow or flag it again as newly
  discovered.
- `scripts/validate-copy.mjs` exists, is dependency-free, and should be re-run after each phase of
  the upcoming UX/form-enhancement work (Phases A–F) as a regression check against this same class
  of wording drift.
- The "Buyer type"/"Preferred contact method" raw-casing display bug (e.g. "SPECIALTY ROASTER"
  instead of "Specialty roaster") found during manual verification is a known, deferred item,
  intentionally left for the upcoming UX enhancement work rather than fixed here.
- Confirm no other part of CLAUDE.md still contradicts the above before finishing.

Commit this CLAUDE.md update on its own, per step 1.

Report back: the final list of commits made (hash + one-line message each), confirmation nothing
was pushed, and the updated CLAUDE.md sections for me to review before I compact this session.
