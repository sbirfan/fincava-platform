Update to the Terms.tsx governing-law work from this phase's kickoff. Two additions — check
whether Terms.tsx has already been updated with the governing-law clause from the kickoff prompt;
if so, this replaces/extends it, if not, use this version instead of the earlier one.

Replace the governing-law section with this expanded version (final, confirmed copy, not a
placeholder):

---

BUSINESS USE ONLY

"The Platform is intended solely for use by business entities engaged in the sourcing, importing,
roasting, brokering, or distribution of coffee, and not by consumers. By creating an account or
submitting any request through the Platform, you represent and warrant that you are acting on
behalf of a business and not as a consumer, and that you have the authority to bind that business
to these Terms."

GOVERNING LAW AND JURISDICTION

"These Terms, and any dispute arising out of or relating to the Platform or these Terms, are
governed by the laws of the State of Texas, without regard to its conflict-of-laws principles. The
parties agree that any such dispute shall be brought exclusively in the state or federal courts
located in Williamson County, Texas, and each party consents to personal jurisdiction and venue
there. If you are located outside the United States, you expressly agree that Texas law and the
forum described above govern these Terms and any dispute, except to the extent a mandatory law of
your jurisdiction that cannot be waived by agreement provides otherwise."

---

Place "Business Use Only" wherever it fits best structurally in the existing Terms — likely near
an eligibility/account-registration section if one exists, otherwise directly before or after the
governing-law section. Use your judgment on exact placement, but don't bury it somewhere a buyer
wouldn't reasonably see it during registration.

Re-run the placeholder-text grep one more time after this change to confirm the full governing-law
section reads as final settled copy, no brackets, no "pending" language anywhere referencing it.

Report back confirming both clauses are in place and the grep is clean, then continue with the
rest of Phase 5 as already scoped.
